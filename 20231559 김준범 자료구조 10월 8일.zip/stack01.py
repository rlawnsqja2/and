# 중간고사 우리가 배우는 연습문제 + 코드 약간
# 일정 크기의 공간이 있어야 한다.
# 파이썬에서는 고정 크기의 배열 없다.
capacity = 5
array = [None] * capacity

# 마지막 데이터 저장 위치
top = -1     # 파이썬에서는 역방향 첨자(index)가 가능한 것에 주의
             # 스택 공간에 음수 첨자 사용을 제한해야 한다.
             # top = -1의 의미는 스택에 데이터 없다.
def push(data):
    #pass
    global top
    global array
    print('변수 top의 id는 ', id(top))
    if not isFull():
        top += 1
        array[top] = data

def pop():
    pass

def isEmpty():
    #if top == -1:
    #    return True
    #else:
    #    return False
    return top == -1

def isFull():
    # if top == capacity -1
    #   return True
    # else:
    #   return False
    return top == capacity-1

if __name__ == "__main__":
    print('main의 top 변수 id는 ', id(top))
    push(10)
    push(20)