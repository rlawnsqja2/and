capacity = 5
array = [None] * (capacity + 1)

# 초기상태
rear = 0
front = 0

def isFull():
    global rear
    #return rear == capacity
    if rear == capacity:
        return True
    else:
        print("Queue가 꽉찼다.")
        return False   
    
def isEmpty():
    global front
    #return front == capacity
    if front == capacity:
        return True
    else:
        print("Queue가 비었다.")
        return False   
    
def enqueue(data):
    global rear
    global front
    global array 
    if not isFull():
        rear += 1               # 마지막에 데이터를 넣은 위치
        array[rear] = data      
    else:
        print("Full이여서 데이터 추가 못함")

def dequeue():                  
    global front            
    global array        
    if not isEmpty():    
        front += 1              # 마지막에 데이터를 꺼낸 위치

        array[front] = None
        return array[front] 
    else:
        print("비어서 꺼내오지 못했다.")
        return None
    

if __name__ == "__main__":
    enqueue(10)
    enqueue(20)
    enqueue(30)
    enqueue(40)
    enqueue(50)
    enqueue(60)
    print(array)
    temp = dequeue()
    print("꺼낸 데이터는 ", temp)
    print(array)
    temp = dequeue()
    print("꺼낸 데이터는 ", temp)
    print(array)
    temp = dequeue()
    print("꺼낸 데이터는 ", temp)
    print(array)
    temp = dequeue()
    print("꺼낸 데이터는 ", temp)
    print(array)
    temp = dequeue()
    print("꺼낸 데이터는 ", temp)
    print(array)
    temp = dequeue()
    print("꺼낸 데이터는 ", temp)
    print(array)