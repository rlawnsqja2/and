class Node:
    def __init__(self):
        self.data = None
        self.next = None