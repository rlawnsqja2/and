a = 3
b = 4
print(f"a={a}, b={b}")
t = a
a = b
b = t
print(f"a={a}, b={b}")
a = 3
b = 4
a, b = b, a
print(f"a={a}, b={b}")