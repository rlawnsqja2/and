package kr.ac.dmu.ai032102

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.annotation.Dimension
import kr.ac.dmu.ai032102.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setContentView(R.layout.activity_main)
        var binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.tvViewText.text = "동양미래대학교"
        binding.tvViewText.setTextSize(30.0F)
        binding.tvViewText.setBackgroundColor(Color.YELLOW)
        binding.button2.text = "패스워드 보기"

        binding.button.setOnClickListener(){
            binding.tvViewText.text = "버튼 클릭되었다."
            binding.tvViewText.setTextColor(Color.RED)
            binding.tvViewText.setTextSize(40.0F)
            binding.tvViewText.text = binding.editText.text

        }
        binding.button2.setOnClickListener(){
            binding.button2.text = binding.editTextPwd.text
        }
    }
}

