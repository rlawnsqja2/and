package kr.ac.dmu.a0523lifecycle2

import android.app.Application

class MyApplication: Application()  {

    // 접근 제한자가 pubic
    var name: String = "홍길동"
    var intData: Int = 200

    init {
        INSTANCE = this
    }

    // java에서 static 데이터
    companion object {
        lateinit var INSTANCE: MyApplication
    }
}