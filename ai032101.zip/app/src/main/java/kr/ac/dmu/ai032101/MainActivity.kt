package kr.ac.dmu.ai032101

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.annotation.Dimension

class MainActivity : AppCompatActivity() { // : 상속
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        // 조작(이용)할 컴포넌트를 찾아야 한다.
        // findViewById() 함수를 사용한다.
        // 컴포넌트를 찾아서 변수에 저장해야한다.
        // 자바에서 정수 변수 : int a = 10;
        // 코틀린에서 정수 변수 : var a:int = 10;
        // 자바에서 객체 변수 : Button b = findViewById(R.id.btnRed)
        // 코틀린에서 : var b: Button = findViewById(R.id.btnRed)
        var btnRed: Button = findViewById<Button>(R.id.btnRed)
        var btnGreen: Button = findViewById<Button>(R.id.btnGreen)
        var btnBlue: Button = findViewById<Button>(R.id.btnBlue)
        var tvViewText: TextView = findViewById(R.id.tvViewText)
        var textSize: Float // float textSize;
        var btnIncSize: Button = findViewById<Button>(R.id.btnIncSize)
        var btnIncSizeMinus: Button = findViewById<Button>(R.id.btnIncSizeMinus)

        tvViewText.setBackgroundColor(Color.YELLOW)
        btnRed.setBackgroundColor(Color.RED)
        btnGreen.setBackgroundColor(Color.GREEN)
        btnBlue.setBackgroundColor(Color.BLUE)
        tvViewText.setTextSize(Dimension.SP, 30.0F)
        textSize = tvViewText.textSize - 100.0F



        btnRed.setOnClickListener(){
            tvViewText.setBackgroundColor(Color.RED)
            tvViewText.setTextColor(Color.BLACK)
            tvViewText.setTextSize(Dimension.SP, 30.0F)
            tvViewText.setText(tvViewText.textSize.toString())
        }
        btnGreen.setOnClickListener(){
            tvViewText.setBackgroundColor(Color.GREEN)
            tvViewText.setTextColor(Color.BLACK)
            tvViewText.setTextSize(Dimension.SP, 40.0F)
        }
        btnBlue.setOnClickListener(){
            tvViewText.setBackgroundColor(Color.BLUE)
            tvViewText.setTextColor(Color.WHITE)
            tvViewText.setTextSize(Dimension.SP, 50.0F)
        }
        btnIncSize.setOnClickListener(){
            tvViewText.setTextSize(Dimension.SP, textSize + 1.0F)
            textSize = tvViewText.textSize
        }
        btnIncSizeMinus.setOnClickListener(){
            tvViewText.setTextSize(Dimension.SP, textSize - 1.0F)
            textSize = tvViewText.textSize
        }



    }
}