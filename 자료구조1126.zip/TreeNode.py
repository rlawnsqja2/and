class TreeNode:
    def __init__(self, data):
        self.left = None
        self.data = data
        self.right = None
