from TreeNode import TreeNode

class BinaryTree:
    def __init__(self, root):
        self.root = root

    def insert(self, tnode):
        # 이진트리에서 기본: 노드의 값보다 작은 값은 왼쪽 서브트리로,
        #                   노드의 값보다 큰 값은 오른쪽 서브트리로...
        current = self.root
        while True: # 언제가지 반복할지 모르기 때문에 무한반복
            # 링크드리스트
            # current = current.next
            if current.data > tnode.data: # 왼쪽 서브트리로 가야한다.
                if current.left == None:  # 왼쪽 서브트리 없다.
                    #pass
                    current.left = tnode
                    break  # 왼쪽 서브 트리가 없으면 더이상 위치를 찾을 일이 없다.
                else:
                    current = current.left
            else:                         # 오른쪽 서브트리로 가야한다.
                if current.right == None:
                    current.right = tnode
                    break
                else:
                    current = current.right


    def search(self, data):
        current = self.root
        isExist = False
        while current is not None:
            if current.data == data:  # 검색하는 데이터가 존재하는 경우
                return True
            elif current.data > data: # 왼쪽 서브트리로 이동
                current = current.left
            else: # 오른쪽 서브 트리로 이동
                current = current.right
        return False # 검색하는 데이터가 존재하지 않는 경우

    def delete(self, data):
        isSearch = False
        current = self.root
        parrent = self.root
        # 찾는 작업
        while current is not None:  #  터미널 노드가 아니면 반복
            if current.data == data:    # 삭제할 데이터 찾았다.
                isSearch = True
                break
            elif current.data > data:   # 왼쪽 서브트리로 이동
                parent = current        # 현재 레벨이 부모가 된다.
                current = current.left  # 다음 레벨로 이동
            else:                       # 오른쪽 서브트리로 이동
                parent = current
                current = current.right
        
        # isSearch 확인 False 이면 더는 할 일이 없다.
        if not isSearch: return False

        # 삭제하는 작업 = 삭제할 데이터는 찾았다.
        # 자식 노드를 찾아가는 링크를 위로 올려야하기 때문에
        # 경우1) 터미널 노드인 경우
        if current.left is None and current.right is None:
            if current.data > data: # 왼쪽 
                parent.left = current.left
            else:                   # 오른쪽
                parent.right = current.left

        # 경우2) 왼쪽 자식노드만 잇는 경우
        if current.left is not None and current.right is None:
            if current.data > data:
                parent.left = current.left
            else:
                parent.right = current.right

        # 경우3) 오른쪽 자식 노드만 있는 경우
        if current.left is None and current.right is not None:
            if current.data > data:
                parent.left = current.right
            else:
                parent.right = current.right

        # 경우4) 오른쪽, 왼쪽 자식 노드가 모두 있는 경우
        if current.left is not None and current.right is not None:
            changeNode = current.right
            changeNodeParent = current.right
            while changeNodeParent == changeNode:   # 터미널을 만나면 둘이 달라진다.
                changeNodeParent = changeNode
                changeNode = changeNode.left
            if changeNode.right is not None:
                changeNodeParent.left = changeNode.right
            else:
                changeNodeParent.left = None
            if data < parent.data:
                parent.left = changeNode
                changeNode.right = current.right
                changeNode.left = current.left
            else:
                parent.right = changeNode
                changeNode.left = current.left
                changeNode.right = current.right
        return True
            
if __name__ == "__main__":
    # root로 사용할 노드를 만들어서 BinaryTree 객체 생성
    tnode = TreeNode(30)
    bt = BinaryTree( tnode )
    # 이진 트리에 넣을 데이터 목록
    arr = [5, 4, 22, 10, 12, 15, 60, 44, 9]
    for i in arr:
        tnode = TreeNode( i )
        bt.insert( tnode )

    # 이진 트리 검색
    print('검색하는 값 10은 있다.', bt.search(10))
    print('검색하는 값 61은 있다.', bt.search(61))

    print("삭제하는 데이터 10 삭제 : ", bt.delete(10)) 
    print("삭제하는 데이터 10 삭제 : ", bt.delete(10)) 
    print('검색하는 값 10은 있다.', bt.search(10))
