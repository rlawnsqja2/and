# 최대 데이터 개수는 확정
# 이진트리에서 최대 데이터 갯수 2개
btarray = [None] * 100
print("배열 크기는 ", len(btarray))
inx = 0
rootinx = 1
while(inx <= 10):
    inx += 1
    data = int(input("이진트리에 추가할 데이터 입력 : "))

    if inx == 1: # 추가 할 데이터는 root node가 된다
        btarray[1] = data
    else:
        if data < btarray[1]: # 왼쪽
            btarray[rootinx * 2] = data 
        else: # 오른쪽
            btarray[rootinx * 2 + 1] = data
