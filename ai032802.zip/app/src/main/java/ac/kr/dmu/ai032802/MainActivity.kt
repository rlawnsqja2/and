package ac.kr.dmu.ai032802

import ac.kr.dmu.ai032802.databinding.ActivityMainBinding
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setContentView(R.layout.activity_main)
        var vb = ActivityMainBinding.inflate(layoutInflater)
        setContentView(vb.root);
    }
}