from Node import Node

class LinkedQueue:

    def __init__(self):
        self.head = None    # linkedlist의 시작 노드 위치
        self.tail = None    # linkedlist의 마지막 노드 위치
        # tail을 별도로 관리하지 않으면
        # 성능에 문제... 데이터 추가(enqueue)할 때는
        # 링크드리스트의 끝까지 찾아가야 하는 문제점이 있다.
        self.qsize = 0

    def enqueue(self, node):
        # 처음 노드인가 아닌가?
        if self.head == None:   # 처음 노드
            self.head = node
            self.tail = node    # linkedlist의 마지막 노드
        else:                   # 이후 노드
            # node.next = None  # Node class에서 처리하고 있다.
            self.tail.next = node
            self.tail = node
        self.qsize += 1
            
            
    def dequeue(self):  # 첫 번째 삭제
        # pass
        if self.head == None: return f"Empty" 
        tmp = self.head.data
        self.head = self.head.next
        self.qsize -= 1
        return f"{tmp}"
    
    def qqsize(self):
        return f"{self.qsize}"
    
    def __str__(self):
        datalist = []
        current = self.head
        while current != None:
            datalist.append(current.data)
            current = current.next
        return f"{datalist}"
    
if __name__ == "__main__":
    lq = LinkedQueue()

    
    
    node = Node()
    node.data = 10
    lq.enqueue(node)
    print(lq)

    node = Node()
    node.data = 5
    lq.enqueue(node)
    print(lq)
        
    node = Node()
    node.data = 15
    lq.enqueue(node)
    print(lq)

    print(lq.dequeue())
    print(lq)
    
    print("큐의 데이터 갯수는 ", lq.qqsize())