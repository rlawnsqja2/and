class TestClass:
    def __init__(self):
        self.item1 = 10
        self.item2 = 20
    def __str__(self):
        return f"객체의 속성값은 {self.item1}과 {self.item2}"           
    
    # 과제