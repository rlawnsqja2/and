from Node import Node
# head(== top)

class LinkedList:
    def __init__(self):
        # 객체의 속성 초기화
        self.head = None


    def push(self, node):
        if self.head == None: # 현재 노드 없다. empty 상태
            #pass
            self.head = node
        else:            # 노드가 있다.
            #pass
            node.next = self.head
            self.head = node

    def __str__(self):
        arr = []
        if self.head == None: return f"{arr}"
        current = self.head
        while(current != None):
            arr.push(current.data)
            current = current.next
        return f"{arr}"


if __name__ == "__main__":
    '''head = None
    node = Node() # data, next
    node.data = 10
    node.next = None
    push(node)
    '''
    llist = LinkedList()
    node = Node()
    node.data = 10
    node.next = None
    llist.push(node)
