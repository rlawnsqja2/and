from Node import Node
# from은 현재 디렉터리의 파일 이름
# import는 해당 파일 내에 있는 class또는 함수 이름


class SimpleLinkedList:
    def __init__(self):
        # class의 속성 정의
        self.head = None

    # class의 함수(메서드) 정의
    def insert(self, node):
        # pass
        # 3가지 경우로 나뉜다.
        # 1. 맨 앞에 insert 되는 경우
        # 2. 노드와 노드 사이에 insert되는 경우
        # 3. 맨 뒤에 insert되는 경우
        if self.head == None: # linkedlist의 첫 번째 노드가 insert되는 경우
            # pass
            self.head = node
        else:
            # pass            # 1, 2, 3을 구분
            # insert 할 위치 결정하는 기준을 데이터 크기(오름차순)
            current = self.head
            backward = self.head
            while current != None:
                #pass
                if node.data > current.data:
                    # 다음 노드로 이동
                    backward = current
                    current = current.next
                else:
                    # 위치 찾은 경우
                    if self.head == current: # 맨 앞
                        node.next = current
                        self.head = node
                    else:
                        node.next = backward.next # 중간
                        backward.next = node
                    break
            else:
                # 끝까지 간 경우(맨 끝에 추가되는 경우)
                node.next = None
                backward.next = node

    def delete(self, data):
        # 처음부터 끝까지 원하는 데이터 찾기
        # self.search(data)
        # 맨 앞에서 삭제하는 경우, 중간에서 삭제하는 경우, 끝에서 삭제하는 경우
        current = self.head
        backward = self.head

        while current != None:
            if current.data == data:
                # 삭제할 데이터를 찾은 경우
                # 맨 앞에서 찾았다.
                if current == self.head: # 맨 앞에서 찾은 경우다
                    self.head = current.next
                else:                    # 맨 앞을 제외한 위치에서 찾았다.
                    backward.next = current.next        
                break
            else:
                backward = current
                current = current.next


    def search(self, data):
        # pass
        # 처음부터 끝까지 원하는 데이터 찾기
        current = self.head
        while not current == None:
            if current.data == data:
                return True
            current = current.next
        return False
    
    def __str__(self):
        llist = [None]
        current = self.head
        while current != None:
            llist.append(current.data)
            current = current.next
        return f"{llist}"
    
if __name__ == "__main__":

    sll = SimpleLinkedList()
    print("단순 링크드 리스트이 head는 ", sll.head)
    node = Node()
    node.data = 20
    sll.insert( node )
    print("단순 링크드 리스트이 head는 ", sll.head)
    print( sll )

    node = Node()
    node.data = 30
    sll.insert( node )
    print( sll )

    node = Node()
    node.data = 50
    sll.insert( node )
    print( sll )

    node = Node()
    node.data = 10
    sll.insert( node )
    print( sll )

    node = Node()
    node.data = 25
    sll.insert( node )
    print( sll )