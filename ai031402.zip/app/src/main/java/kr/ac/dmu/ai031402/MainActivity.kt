package kr.ac.dmu.ai031402

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var btnTransfer: Button = findViewById<Button>(R.id.button)
        var tvview: TextView = findViewById<TextView>(R.id.textView)
        var inputText: EditText = findViewById<EditText>(R.id.editTextText)

        btnTransfer.setOnClickListener(){
            tvview.text = inputText.text  //  concat(text,"!!")
        }
    }

}