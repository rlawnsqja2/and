arr = [5, 3, 8, 4, 9, 1, 6, 2, 7]

key = int(input("검색할 데이터는: "))
for i in range(0, len(arr)):
    found = False
    if key == arr[i]:
        #print(f"찾았다. {i}번째에 있다.")
        found = True
        break

if not found:
    print("못 찾았다. 없다.")
else:
    print(f"찾았다. {i}번째에 있다.")
    