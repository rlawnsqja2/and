# 이진 검색
# 이진 검색의 전제 조건 == 데이터가 반드시 정렬되어 있어야 한다.
# 오름차순으로 되어 있다.
# 검색 범위 결정 : low, middle, high - 데이터의 위치(첨자, 인덱스)
data = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
found = False

key = int(input("찾을 데이터는: "))
low = 0
# high = 9     # 데이터의 갯수가 변경되면 상수도 변경된다. ...
high = len(data) - 1
middle = (low + high) // 2    # 반드시 정수값으로 계산해야 한다.
while low <= high:
    if data[middle] == key:
        print("찾는 데이터가 있다.")
        found = True
        break
    elif data[middle] < key:
        # 오름차순이면 middle 번째의 오른쪽 데이터만 검색
        low = middle + 1
        middle = (low + high) // 2
    else: 
        # 오름차순이면 middle 번째의 왼쪽 데이터만 검색
        high = middle - 1
        middle = (low + high) // 2

if not found:
    print("못 찾았다.")