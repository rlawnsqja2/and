class Record:
    def __init__(self, no, name, kor, eng):
        self.no = no
        self.name = name
        self.kor = kor
        self.eng = eng
        self.avg = (self.kor + self.eng) /2

    def __str__(self):
        return f"{self.no} {self.name} {self.kor} {self.eng} {self.avg}"