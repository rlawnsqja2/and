from Record import Record

# 데이터 준비
studentList = []
s1 = Record(1, "홍길동", 100, 100)
studentList.append(s1)
s1 = Record(2, "장길산", 90, 90)
studentList.append(s1)
s1 = Record(3, "홍길서", 85, 88)
studentList.append(s1)

# 1. 순차 검색 : 번호로 검색
key = int(input("검색하려는 학생의 번호를 입력하세요 : "))
found = False
for i in range(0, len(studentList)):
    if key == studentList[i].no:
        # 찾았다.
        found = True
        break
    else:
        # 못찾았다.
        pass
# 반복 종료한 뒤에...
if found:
    print(f"찾았다. {i} 번째에 있다. ")
    print(studentList[i])
else:
    print("못 찾있다. 찾는 데이터가 없다.")