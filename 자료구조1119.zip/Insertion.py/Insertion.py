arr = [5, 3, 8, 4, 9, 1, 6, 2, 7]
# 삽입 정렬
insertData = 1
# 비교 대상 (insertData -1)..0 = j번째
#       tmp = arr[insertData-1]
# 비교 if arr[j] > arr[insertData]:
# 위치 교환 X
# arr[insertData] = arr[j]

# 선택한 위치 i
# 비교 대상은 j
# 예...
# i = 3 --- i를 1부터 len(arr)까지 반복
for i in range(1, len(arr)):
    tmp = arr[i]
    found = False
    # 위치를 찾았다. found = False
    for j in range(i - 1, -1, -1):
        if  arr[j] > tmp:
            print("비교하는 값: ", arr[j], " vs ", tmp)
            arr[j+1] = arr[j]
        else:
            found = True
            break # 더는 위치를 찾을 필요가 없다.

    if found:
        arr[j+1] = tmp
        print("j+1", j+1)   
    else:
        if j == 0:
            print(f"{i}회전: {arr}")

print("결과", arr)